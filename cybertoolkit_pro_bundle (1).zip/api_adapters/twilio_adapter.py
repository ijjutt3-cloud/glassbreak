# Twilio Lookup (carrier/line type). Requires TWILIO_ACCOUNT_SID + TWILIO_AUTH_TOKEN env vars.
import os, requests
SID = os.environ.get('TWILIO_ACCOUNT_SID')
TOKEN = os.environ.get('TWILIO_AUTH_TOKEN')
def lookup_number(number):
    if not (SID and TOKEN):
        print('Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN'); return
    url = f'https://lookups.twilio.com/v1/PhoneNumbers/{number}?Type=carrier'
    r = requests.get(url, auth=(SID, TOKEN), timeout=10)
    print(r.status_code, r.text[:1000])
