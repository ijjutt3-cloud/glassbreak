# NumVerify adapter (format/carrier/country). Requires NUMVERIFY_KEY env var.
import os, requests
KEY = os.environ.get('NUMVERIFY_KEY')
def lookup_number(number):
    if not KEY:
        print('Set NUMVERIFY_KEY'); return
    r = requests.get(f'http://apilayer.net/api/validate?access_key={KEY}&number={number}', timeout=10)
    print(r.status_code, r.text[:1000])
