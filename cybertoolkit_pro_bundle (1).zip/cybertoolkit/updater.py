import requests
from .utils import load_config

def check_update():
    cfg = load_config()
    # Change YOUR_USERNAME/REPO if you host this on GitHub
    repo_raw = 'https://raw.githubusercontent.com/YOUR_USERNAME/cybertoolkit-pro/main/VERSION'
    try:
        r = requests.get(repo_raw, timeout=5)
        if r.ok:
            latest = r.text.strip()
            curr = cfg.get('general', {}).get('version')
            if latest and curr and latest != curr:
                print('Update available:', latest)
            else:
                print('Up to date')
        else:
            print('Update check failed:', r.status_code)
    except Exception as e:
        print('Update check error:', e)
