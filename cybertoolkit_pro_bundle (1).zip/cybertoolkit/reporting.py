import os, time
from jinja2 import Environment, FileSystemLoader
TEMPL_DIR = os.path.join(os.path.dirname(__file__), 'templates')
env = Environment(loader=FileSystemLoader(TEMPL_DIR))

def write_report(data, outdir='./reports'):
    os.makedirs(outdir, exist_ok=True)
    html = env.get_template('report.html').render(data=data, generated=int(time.time()))
    path = os.path.join(outdir, f'report_{int(time.time())}.html')
    with open(path, 'w', encoding='utf-8') as f: f.write(html)
    print('HTML report:', path)
    return path
