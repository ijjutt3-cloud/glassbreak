import argparse
from . import scanner, vault, alerts, reporting, updater, webui

def main():
    parser = argparse.ArgumentParser(prog='cybertoolkit', description='CyberToolkit Pro (Defensive)')
    sub = parser.add_subparsers(dest='cmd')

    p_scan = sub.add_parser('scan', help='Multi-threaded network scanner')
    p_scan.add_argument('--network', required=True, help='CIDR, e.g. 192.168.1.0/24')
    p_scan.add_argument('--ports', default=None, help='Comma-separated ports, default preset')

    p_vault = sub.add_parser('vault', help='Encrypted vault (Argon2 + AESGCM)')
    p_vault.add_argument('action', choices=['init','add','get'])
    p_vault.add_argument('--name', help='Entry name')

    p_alerts = sub.add_parser('alerts', help='Send test alerts')
    p_alerts.add_argument('--test', action='store_true')

    p_web = sub.add_parser('webui', help='Start simple web UI')
    p_web.add_argument('--host', default='127.0.0.1')
    p_web.add_argument('--port', type=int, default=8080)

    sub.add_parser('update', help='Check for updates')

    args = parser.parse_args()

    if args.cmd == 'scan':
        ports = None
        if args.ports:
            try:
                ports = [int(x.strip()) for x in args.ports.split(',') if x.strip()]
            except Exception:
                print('Invalid --ports, using defaults')
        scanner.scan(args.network, ports)
    elif args.cmd == 'vault':
        if args.action == 'init':
            vault.init_vault()
        elif args.action == 'add':
            vault.add_entry(args.name)
        elif args.action == 'get':
            vault.get_entry(args.name)
    elif args.cmd == 'alerts' and args.test:
        alerts.test_alerts()
    elif args.cmd == 'webui':
        webui.run(host=args.host, port=args.port)
    elif args.cmd == 'update':
        updater.check_update()
    else:
        parser.print_help()
