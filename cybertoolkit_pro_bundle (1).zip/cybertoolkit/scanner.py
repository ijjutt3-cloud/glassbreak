import ipaddress, socket, concurrent.futures, time
from .utils import print_ok, print_warn
DEFAULT_PORTS = [22,80,443,445,3389,3306,8080]

def _scan_port(ip, port, timeout=0.6):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        r = s.connect_ex((str(ip), port))
        return port if r == 0 else None
    except Exception:
        return None
    finally:
        s.close()

def _scan_ip(ip, ports):
    open_ports = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(64, len(ports))) as ex:
        futures = {ex.submit(_scan_port, ip, p): p for p in ports}
        for fut in concurrent.futures.as_completed(futures):
            r = fut.result()
            if r:
                open_ports.append(r)
    return {'ip': str(ip), 'open_ports': sorted(open_ports)} if open_ports else None

def scan(network, ports=None, threads=200):
    if ports is None:
        ports = DEFAULT_PORTS
    net = ipaddress.ip_network(network, strict=False)
    ips = list(net.hosts())
    print(f"Scanning {len(ips)} hosts...")
    start = time.time()
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(_scan_ip, ip, ports): ip for ip in ips}
        for fut in concurrent.futures.as_completed(futures):
            r = fut.result()
            if r:
                print_ok(f"{r['ip']} open: {r['open_ports']}")
                results.append(r)
    print(f"Done in {time.time()-start:.1f}s, hosts with open ports: {len(results)}")
    return results
