import os, toml

CONFIG_PATH = os.path.expanduser('~/.cybertoolkit/config.toml')

def load_config():
    try:
        if os.path.exists(CONFIG_PATH):
            return toml.load(CONFIG_PATH)
    except Exception:
        pass
    return {}

def print_ok(msg): print('[OK]', msg)
def print_warn(msg): print('[WARN]', msg)
