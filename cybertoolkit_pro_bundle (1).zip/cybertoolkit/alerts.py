import smtplib
from email.message import EmailMessage
import requests
from .utils import load_config

cfg = load_config()

def send_email(subject, body):
    s = cfg.get('alerts', {}).get('smtp', {})
    if not s.get('enabled'): return False
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = s.get('from')
    msg['To'] = s.get('username')
    msg.set_content(body)
    try:
        with smtplib.SMTP(s['server'], s['port']) as server:
            server.starttls()
            server.login(s['username'], s['password'])
            server.send_message(msg)
        return True
    except Exception as e:
        print('Email send failed:', e); return False

def send_telegram(text):
    t = cfg.get('alerts', {}).get('telegram', {})
    if not t.get('enabled'): return False
    token = t.get('bot_token'); chat = t.get('chat_id')
    url = f'https://api.telegram.org/bot{token}/sendMessage'
    try:
        r = requests.post(url, json={'chat_id': chat, 'text': text}, timeout=8)
        return r.ok
    except Exception as e:
        print('Telegram send failed:', e); return False

def test_alerts():
    ok1 = send_email('CyberToolkit Pro — Test', 'This is a test email')
    ok2 = send_telegram('CyberToolkit Pro — Test Telegram')
    print('Email:', ok1, 'Telegram:', ok2)
