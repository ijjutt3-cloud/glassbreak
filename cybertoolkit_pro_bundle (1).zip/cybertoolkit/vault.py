import os, json, secrets
from getpass import getpass
from argon2.low_level import hash_secret_raw, Type as Argon2Type
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

VAULT_PATH = os.path.expanduser('~/.cybertoolkit/vault.enc')
SALT_PATH = os.path.expanduser('~/.cybertoolkit/salt.bin')

def _derive_key(password, salt):
    # Argon2id parameters (tuned for desktop; increase if desired)
    t_cost = 3
    m_cost = 2**16  # 64 MiB
    parallelism = 2
    key = hash_secret_raw(password.encode('utf-8'), salt, t_cost, m_cost, parallelism, 32, Argon2Type.ID)
    return key

def init_vault():
    if os.path.exists(VAULT_PATH):
        print('Vault already exists.'); return
    pw = getpass('Choose master password: ')
    os.makedirs(os.path.dirname(VAULT_PATH), exist_ok=True)
    salt = secrets.token_bytes(16)
    with open(SALT_PATH, 'wb') as f: f.write(salt)
    key = _derive_key(pw, salt)
    aes = AESGCM(key)
    data = json.dumps({'entries':{}}).encode()
    nonce = secrets.token_bytes(12)
    ct = aes.encrypt(nonce, data, None)
    with open(VAULT_PATH, 'wb') as f: f.write(nonce+ct)
    print('Vault initialized.')

def _load_vault(pw):
    if not os.path.exists(VAULT_PATH): raise Exception('Vault not initialized')
    salt = open(SALT_PATH,'rb').read()
    key = _derive_key(pw, salt)
    aes = AESGCM(key)
    raw = open(VAULT_PATH,'rb').read()
    nonce, ct = raw[:12], raw[12:]
    data = aes.decrypt(nonce, ct, None)
    return json.loads(data.decode()), key

def _save_vault(vault, key):
    aes = AESGCM(key)
    nonce = secrets.token_bytes(12)
    ct = aes.encrypt(nonce, json.dumps(vault).encode(), None)
    with open(VAULT_PATH,'wb') as f: f.write(nonce+ct)

def add_entry(name):
    if not name:
        name = input('Entry name: ').strip()
    pw = getpass('Master password: ')
    vault, key = _load_vault(pw)
    secret = getpass('Secret/value: ')
    vault['entries'][name] = {'value': secret}
    _save_vault(vault, key)
    print('Entry added.')

def get_entry(name):
    if not name:
        name = input('Entry name: ').strip()
    pw = getpass('Master password: ')
    vault, _ = _load_vault(pw)
    e = vault['entries'].get(name)
    if not e:
        print('Not found')
        return None
    print('Value:', e['value'])
    return e['value']
