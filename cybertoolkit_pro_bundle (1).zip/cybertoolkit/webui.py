from flask import Flask, render_template, request, flash
from . import scanner, vault
app = Flask(__name__)
app.secret_key = 'change_me_for_prod'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan', methods=['GET','POST'])
def scan_route():
    results = None
    if request.method == 'POST':
        network = request.form.get('network','')
        ports_raw = request.form.get('ports','')
        ports = [int(p.strip()) for p in ports_raw.split(',') if p.strip().isdigit()] if ports_raw else None
        results = scanner.scan(network, ports)
    return render_template('scan.html', results=results)

@app.route('/vault', methods=['GET','POST'])
def vault_route():
    if request.method == 'POST':
        action = request.form.get('action')
        name = request.form.get('name') or None
        if action == 'init':
            vault.init_vault(); flash('Vault initialized')
        elif action == 'add':
            vault.add_entry(name); flash(f'Entry "{name}" added')
        elif action == 'get':
            val = vault.get_entry(name); flash(f'Value: {val}')
    return render_template('vault.html')

def run(host='127.0.0.1', port=8080):
    app.run(host=host, port=port)
