# CyberToolkit Pro (Defensive, Legal)

**Use only on systems/networks you own or where you have explicit authorization.**  
This toolkit helps you harden, monitor, and collect evidence. It does **not** deanonymize people or track private GPS data.

## Contents
- `collector.py` – Evidence collector (hash + metadata + ZIP)
- `docker-compose.yml` – Cowrie honeypot (SSH/Telnet, containerized)
- `config.example.toml` – App config example
- `cybertoolkit/` – Package (scanner, vault with Argon2+AESGCM, alerts, reporting, updater, utils, web UI)
- `osint_tools/` – Public-only OSINT helpers
- `api_adapters/` – Twilio/Numverify templates (keys required)
- `incident_report/` – Template to report to authorities
- `extras/` – PCAP scripts, encrypt helper
- `diagram.png` – Architecture overview

## Install
```bash
python -m pip install -r requirements.txt
```

## Config
Copy `config.example.toml` to your user config:
- Linux/Mac: `~/.cybertoolkit/config.toml`
- Windows: `%USERPROFILE%\.cybertoolkit\config.toml`

Fill SMTP + Telegram settings if you want alerts.

## CLI
```bash
python -m cybertoolkit --help
python -m cybertoolkit scan --network 192.168.1.0/24
python -m cybertoolkit vault init
python -m cybertoolkit webui --host 0.0.0.0 --port 8080
python collector.py --cowrie-dir ./cowrie/log --out ./evidence
```

## Honeypot (Cowrie)
1) Install Docker, then:
```bash
docker compose up -d
```
Logs will appear in `./cowrie/log/`. Keep honeypot isolated (VM/VLAN).

## Legal
- Don’t attack others. Don’t attempt private tracking. If you gather evidence of crimes, contact law enforcement / CERT.
