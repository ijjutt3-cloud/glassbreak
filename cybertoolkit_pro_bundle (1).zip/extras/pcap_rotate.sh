#!/usr/bin/env bash
OUTDIR=./pcaps
mkdir -p "$OUTDIR"
FILE="$OUTDIR/capture_$(date -u +%Y%m%dT%H%M%SZ).pcap"
echo "Capturing to $FILE (CTRL+C to stop)"
sudo tcpdump -i any -w "$FILE"
