from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os, sys
def encrypt_file(inpath, outpath, key_hex=None):
    key = bytes.fromhex(key_hex) if key_hex else AESGCM.generate_key(bit_length=256)
    if not key_hex: print('Generated key (store securely):', key.hex())
    aes = AESGCM(key)
    nonce = os.urandom(12)
    data = open(inpath,'rb').read()
    ct = aes.encrypt(nonce, data, None)
    open(outpath,'wb').write(nonce+ct)
    print('Wrote', outpath)
if __name__=='__main__':
    print('Usage: encrypt_file("evidence.zip","evidence.enc","<optional hex key>")')
