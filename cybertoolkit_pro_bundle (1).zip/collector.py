#!/usr/bin/env python3
"""Defensive evidence collector: copies logs, computes hashes, writes METADATA, creates ZIP."""
import os, json, hashlib, shutil, argparse
from datetime import datetime

def sha256(path):
    h = hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def collect(source_dir, out_dir):
    ts = datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
    bundle_dir = os.path.join(out_dir, f'evidence_{ts}')
    os.makedirs(bundle_dir, exist_ok=True)
    meta = {'collected_at_utc': ts, 'source': os.path.abspath(source_dir), 'files': []}
    for root, _, files in os.walk(source_dir):
        for fn in files:
            src = os.path.join(root, fn)
            rel = os.path.relpath(src, source_dir)
            dst = os.path.join(bundle_dir, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            meta['files'].append({'path': rel, 'sha256': sha256(dst), 'size': os.path.getsize(dst)})
    meta_path = os.path.join(bundle_dir, 'METADATA.json')
    with open(meta_path, 'w', encoding='utf-8') as fh:
        json.dump(meta, fh, indent=2)
    shutil.make_archive(bundle_dir, 'zip', bundle_dir)
    print('Evidence bundle:', bundle_dir + '.zip')
    return bundle_dir + '.zip'

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--cowrie-dir', default='./cowrie/log', help='Source log directory')
    ap.add_argument('--out', default='./evidence', help='Output directory')
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    if not os.path.isdir(args.cowrie_dir):
        print('Source dir not found:', args.cowrie_dir)
    else:
        collect(args.cowrie_dir, args.out)
