# Incident Report — CyberToolkit Pro

**Reporter:** [Your Name / Org]  
**Date (UTC):** [YYYY-MM-DD]  
**Contact:** [Email / Phone]

## Summary
Concise description of the incident.

## Evidence
List of files attached (with SHA256). Include evidence ZIP from collector.

## Timeline (UTC)
- 2025-01-01 10:00:00 — Event ...
- ...

## Indicators of Compromise (IOCs)
- IPs: ...
- Domains: ...
- Hashes: ...

## Actions Taken
- Isolation, snapshots, logging enabled, honeypot actions, etc.

## Request
Please assist with lawful attribution and any subscriber information via proper legal process.
