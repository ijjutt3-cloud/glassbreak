import os, requests
API_KEY = os.environ.get('VT_API_KEY')
def vt_hash_lookup(h):
    if not API_KEY:
        print('Set VT_API_KEY in environment.')
        return
    r = requests.get(f'https://www.virustotal.com/api/v3/files/{h}', headers={'x-apikey': API_KEY}, timeout=10)
    print('Status:', r.status_code)
    if r.ok: print(r.json())
