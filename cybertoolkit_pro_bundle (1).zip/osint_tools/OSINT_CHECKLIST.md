# OSINT Checklist (Public-Only, Legal)

- Save evidence (logs, timestamps, hashes).
- Search number/strings on search engines using operators (site:, intext:).
- Check public paste sites, social networks, public breach news (no illegal DBs).
- WHOIS / DNS / passive DNS where permitted.
- Record URLs, take screenshots, store in evidence bundle.
- Never harass or threaten; hand over to authorities if needed.
