#!/usr/bin/env python3
import argparse
from urllib.parse import quote_plus

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('number', help='Phone number to search')
    args = ap.parse_args()
    q = args.number
    print('Open these in a browser for manual review:')
    print('Google:', 'https://www.google.com/search?q=' + quote_plus(q))
    print('Bing  :', 'https://www.bing.com/search?q=' + quote_plus(q))
    print('Paste helper:', 'https://search.betterttg.xyz/?q=' + quote_plus(q))

if __name__ == '__main__':
    main()
